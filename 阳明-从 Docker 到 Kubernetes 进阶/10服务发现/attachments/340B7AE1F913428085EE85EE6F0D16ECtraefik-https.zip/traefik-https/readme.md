
Traefik & Kubernetes TLS DEMO:
https://doc.traefik.io/traefik/routing/providers/kubernetes-ingress/#tls

开启 traefik dashboard 的方法(http和https开启的方式不一样):
https://doc.traefik.io/traefik/operations/dashboard/

traefik 配置文件引入方法:
https://doc.traefik.io/traefik/providers/file/

Configuration Introduction
https://doc.traefik.io/traefik/getting-started/configuration-overview/

basicauth
https://doc.traefik.io/traefik/middlewares/http/basicauth/#usersfile


https://www.example.com:30646/bar
https://www.example.com:30646/foo
https://aaron.example.com:30646/bar
https://aaron.example.com:30646/foo


[root@centos7 traefik-https]# kubectl get svc
NAME         TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)         AGE
traefik      NodePort    10.108.121.202   <none>        443:30646/TCP   2d4h
whoami       ClusterIP   10.104.191.105   <none>        80/TCP          2d4h

访问 whoami 服务:
    https://www.example.com:30646/bar
    https://www.example.com:30646/foo
    https://aaron.example.com:30646/bar
    https://aaron.example.com:30646/foo

traefik dashboard主页
    在 hosts 文件中配置: 
        192.168.32.100  traefik.aaron.com
    访问 traefik dashboard(注意路径最后的"/",少了"/"页面会出现404): 
        https://traefik.aaron.com:30646/dashboard/
